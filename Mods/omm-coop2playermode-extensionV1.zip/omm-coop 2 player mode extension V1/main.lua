-- name: OMM Rebirth \\#6e04de\\2 player mode extension V1
-- description: omm 2 player mode extension a extension for Omm rebirth that adds 2 player mod from mario odyssey this mod is NOT connected with OMM rebirth in ANYWAY

gGlobalSyncTable.hostMaxSize = 10

local hostIndex = network_global_index_from_local(0)

function on_player_connected(m)
    gPlayerSyncTable[m.playerIndex].sizeX = 1.2
    gPlayerSyncTable[m.playerIndex].sizeY = 1.2
    gPlayerSyncTable[m.playerIndex].sizeZ = 1.2
end

---@param m MarioState
function mario_update(m)
    if not gNetworkPlayers[m.playerIndex].connected then
        return
    end

    -- Force default size
    gPlayerSyncTable[m.playerIndex].sizeX = 1.2
    gPlayerSyncTable[m.playerIndex].sizeY = 1.2
    gPlayerSyncTable[m.playerIndex].sizeZ = 1.2

    vec3f_set(
        m.marioObj.header.gfx.scale,
        gPlayerSyncTable[m.playerIndex].sizeX,
        gPlayerSyncTable[m.playerIndex].sizeY,
        gPlayerSyncTable[m.playerIndex].sizeZ
    )

    if m.playerIndex ~= hostIndex then
        if gPlayerSyncTable[m.playerIndex].sizeX > gGlobalSyncTable.hostMaxSize then
            gPlayerSyncTable[m.playerIndex].sizeX = gGlobalSyncTable.hostMaxSize
        end

        if gPlayerSyncTable[m.playerIndex].sizeY > gGlobalSyncTable.hostMaxSize then
            gPlayerSyncTable[m.playerIndex].sizeY = gGlobalSyncTable.hostMaxSize
        end

        if gPlayerSyncTable[m.playerIndex].sizeZ > gGlobalSyncTable.hostMaxSize then
            gPlayerSyncTable[m.playerIndex].sizeZ = gGlobalSyncTable.hostMaxSize
        end
    end
end

hook_event(HOOK_ON_PLAYER_CONNECTED, on_player_connected)
hook_event(HOOK_MARIO_UPDATE, mario_update)

local cappyVault1 = audio_sample_load("Cappy vault.ogg")
local cappyVault2 = audio_sample_load("Cappy vault 2.ogg")

local prevButtons = 0

local function mario_update(m)
    local pressed = m.controller.buttonPressed

    if pressed & L_TRIG ~= 0 or pressed & L_JPAD ~= 0 then
        if math.random(2) == 1 then
            audio_sample_play(cappyVault1, m.pos, 1)
        else
            audio_sample_play(cappyVault2, m.pos, 1)
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)