--Custom Star Teleport Mod

local TELEPORT_DISTANCE = 6234
local TELEPORT_CHARGE_TIME = 30
local STRETCH_FRAMES = 7

local teleport_timer = {}
local stretch_timer = {}

for i = 0, (MAX_PLAYERS - 1) do
    teleport_timer[i] = 0
    stretch_timer[i] = 0
end

function teleport_forward(m)
    if m.action == ACT_CROUCHING then
        if (m.controller.buttonDown & R_JPAD) ~= 0 then
            teleport_timer[m.playerIndex] = teleport_timer[m.playerIndex] + 1

            if teleport_timer[m.playerIndex] >= TELEPORT_CHARGE_TIME then
                -- fix: flip camera yaw so it matches screen-facing direction
                local angle = gLakituState.yaw + 0x8000

                local dx = math.sin(angle * math.pi / 0x8000) * TELEPORT_DISTANCE
                local dz = math.cos(angle * math.pi / 0x8000) * TELEPORT_DISTANCE

                m.pos.x = m.pos.x + dx
                m.pos.z = m.pos.z + dz

                -- trigger stretch effect
                stretch_timer[m.playerIndex] = STRETCH_FRAMES

                teleport_timer[m.playerIndex] = 0 -- reset
            end
        else
            teleport_timer[m.playerIndex] = 0
        end
    else
        teleport_timer[m.playerIndex] = 0
    end

    if stretch_timer[m.playerIndex] > 0 then
        m.marioObj.header.gfx.scale.y = 2.0 -- stretch tall
        m.marioObj.header.gfx.scale.x = 0.8 -- squash width
        m.marioObj.header.gfx.scale.z = 0.8
        stretch_timer[m.playerIndex] = stretch_timer[m.playerIndex] - 1
    else

        m.marioObj.header.gfx.scale.x = 1
        m.marioObj.header.gfx.scale.y = 1
        m.marioObj.header.gfx.scale.z = 1
    end
end

hook_event(HOOK_MARIO_UPDATE, teleport_forward)
