yo thanks for downloading

you can do whatever you want with this, no credit or permission needed (even though credit is appreciated)
just don't straight up claim it as yours, that's pretty much all i ask

anyway, just copy/move this folder to '/storage/emulated/0/com.maniscat2.sm64coopdx/dynos/packs' (you might need to create the last two folders) and it should be listed in your dynos packs

---------------
v1.1 changelog:
* added new textures for the joystick and joystick base, based on the original ones by xLuigiGamerx
* removed unused textures as of Av1.4 (confirm, discard, reset and grid buttons)
* edited the Z button texture shading slightly
---------------

hope you like it
- mingokrb