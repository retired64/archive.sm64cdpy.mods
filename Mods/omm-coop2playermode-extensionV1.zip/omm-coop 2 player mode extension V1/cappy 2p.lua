-- name: Hats
-- description: Hats v1.0.1\nBy \\#dd7032\\CosmicMan08\\#dcdcdc\\ and \\#ec7731\\Agent X\n\n\\#dcdcdc\\This mod adds 15 hats to sm64ex-coop being a top hat, crown, halo, cape, sonic hair, dr headband, raccoon ears and tail, chain chomp, artisan, bone brim, slumber, sign, pipe and water bomb.\n\nUse /hat [0-15] to select your hat, 0\nbeing none.

define_custom_obj_fields({
    oHatOwner = 'u32',
    oHatScale = 'f32',
    oHatPlaced = 'u32',
    oHatFlipped = 'u32',
})

local CAPPY_NONE      = 0
local CAPPY_1   = 1

local CAPPY_MOVE_SPEED = 20  -- Medium speed for hat movement

local function resolve_model_id(spec)
    if type(spec) == "number" then return spec end
    if type(spec) == "string" then
        if _G[spec] ~= nil and type(_G[spec]) == "number" then
            return _G[spec]
        end
        local ok, id = pcall(smlua_model_util_get_id, spec)
        if ok and id and id ~= 0 then return id end
        local alt = spec:gsub("%.bin$", "")
        ok, id = pcall(smlua_model_util_get_id, alt)
        if ok and id and id ~= 0 then return id end
        local name = alt:upper():gsub("[^A-Z0-9_]", "_")
        local varname = "E_MODEL_" .. name
        if _G[varname] ~= nil and type(_G[varname]) == "number" then
            return _G[varname]
        end
    end
    return nil
end

local gHatList = {
    [CAPPY_1]    = { modelSpec = "cappy_geo",   cap = false, modelId = nil, size = 1.2 },
}

local function active_player(m)
    local np = gNetworkPlayers[m.playerIndex]
    if m.playerIndex == 0 then return 1 end
    if not np.connected then return 0 end
    if np.currCourseNum ~= gNetworkPlayers[0].currCourseNum then return 0 end
    if np.currActNum ~= gNetworkPlayers[0].currActNum then return 0 end
    if np.currLevelNum ~= gNetworkPlayers[0].currLevelNum then return 0 end
    if np.currAreaIndex ~= gNetworkPlayers[0].currAreaIndex then return 0 end
    return is_player_active(m)
end

local function bhv_hat_init(o)
    o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    cur_obj_scale(1)
    o.oHatScale = 1
    o.oHatPlaced = 0
    o.oHatFlipped = 0
    o.hitboxRadius = 0
    o.hitboxHeight = 0
    cur_obj_hide()
end

local function bhv_hat_loop(o)
    cur_obj_scale(o.oHatScale or 1)

    local np = network_player_from_global_index(o.oHatOwner)
    if np == nil or gPlayerSyncTable[np.localIndex].hat == CAPPY_NONE then
        obj_mark_for_deletion(o)
        return
    end
    local m = gMarioStates[np.localIndex]
    if active_player(m) == 0 then
        obj_mark_for_deletion(o)
        return
    end

    if o.oHatPlaced == 0 then
        local floatOffset = 105
        o.oPosX = m.marioBodyState.headPos.x + m.vel.x
        o.oPosY = m.marioBodyState.headPos.y + m.vel.y + floatOffset
        o.oPosZ = m.marioBodyState.headPos.z + m.vel.z
        o.oFaceAnglePitch = m.marioObj.header.gfx.angle.x + (m.marioBodyState.torsoAngle.x * 0.5)
        o.oFaceAngleYaw   = m.marioObj.header.gfx.angle.y + (m.marioBodyState.torsoAngle.y * 0.5)
        o.oFaceAngleRoll  = m.marioObj.header.gfx.angle.z + (m.marioBodyState.torsoAngle.z * 0.5)
    else
        if o.oHatFlipped == 1 then
            o.oFaceAnglePitch = o.oFaceAnglePitch + 0x1800
            o.oFaceAngleRoll = 0x4000
        else
            o.oFaceAngleYaw = o.oFaceAngleYaw + 0x1800
            o.oFaceAngleRoll = 0
            end
    end

    cur_obj_unhide()

    local hatId = gPlayerSyncTable[m.playerIndex].hat
    local info = gHatList[hatId]
    if info and info.modelId then
        obj_set_model_extended(o, info.modelId)
    end
end

local id_bhvCappy2P = hook_behavior(nil, OBJ_LIST_GENACTOR, true, bhv_hat_init, bhv_hat_loop)

local function ensure_models_resolved()
    for id, info in pairs(gHatList) do
        if info and not info.modelId then
            local resolved = resolve_model_id(info.modelSpec)
            info.modelId = resolved
        end
    end
end

local function mario_update(m)
    if gPlayerSyncTable[m.playerIndex].hat == CAPPY_NONE or active_player(m) == 0 then return end

    ensure_models_resolved()
    local hatId = gPlayerSyncTable[m.playerIndex].hat
    local info = gHatList[hatId] or {}

    pcall(function() m.marioBodyState.capState = MARIO_HAS_DEFAULT_CAP_OFF end)

    if not info.cap then
        local hat = obj_get_first_with_behavior_id(id_bhvCappy2P)
        while hat ~= nil do
            if hat.oHatOwner == gNetworkPlayers[m.playerIndex].globalIndex then break end
            hat = obj_get_next_with_same_behavior_id(hat)
        end
        if hat == nil then
            local modelToSpawn = (info.modelId ~= nil) and info.modelId or E_MODEL_NONE
            spawn_non_sync_object(id_bhvCappy2P, modelToSpawn, m.pos.x, m.pos.y, m.pos.z, function(o)
                o.oHatOwner = gNetworkPlayers[m.playerIndex].globalIndex
                o.oHatScale = info.size or 1.0
            end)
        end

        hat = obj_get_first_with_behavior_id(id_bhvCappy2P)
        while hat ~= nil do
            if hat.oHatOwner == gNetworkPlayers[m.playerIndex].globalIndex then break end
            hat = obj_get_next_with_same_behavior_id(hat)
        end

        if hat ~= nil then
            if m.controller.buttonDown & L_TRIG ~= 0 then
                hat.oHatScale = (info.size or 1.0) * 1.6
            else
                hat.oHatScale = info.size or 1.0
            end

            if m.controller.buttonPressed & X_BUTTON ~= 0 and hat.oHatPlaced == 0 then
                local forwardOffset = 500
                local upwardOffset = 350
                local downwardOffset = -350
                if m.controller.buttonDown & U_JPAD ~= 0 then
                    hat.oPosX = m.pos.x
                    hat.oPosY = m.pos.y + upwardOffset
                    hat.oPosZ = m.pos.z
                elseif m.controller.buttonDown & D_JPAD ~= 0 then
                    hat.oPosX = m.pos.x
                    hat.oPosY = m.pos.y + downwardOffset
                    hat.oPosZ = m.pos.z
                else
                    hat.oPosX = m.pos.x + sins(m.faceAngle.y) * forwardOffset
                    hat.oPosY = m.pos.y
                    hat.oPosZ = m.pos.z + coss(m.faceAngle.y) * forwardOffset
                end
                hat.oHatPlaced = 1
            end

            if m.controller.buttonPressed & U_JPAD ~= 0 and hat.oHatPlaced == 1 then
                hat.oHatPlaced = 0
            end

            if hat.oHatPlaced == 1 and m.controller.buttonPressed & R_JPAD ~= 0 then
                hat.oHatFlipped = 1 - hat.oHatFlipped
            end

            -- Move Cappy left and right when thrown
            if hat.oHatPlaced == 1 then
                if m.controller.buttonDown & L_JPAD ~= 0 then
                    -- Move left (perpendicular to Mario's facing angle)
                    local leftAngle = m.faceAngle.y + 0x4000
                    hat.oPosX = hat.oPosX + sins(leftAngle) * CAPPY_MOVE_SPEED
                    hat.oPosZ = hat.oPosZ + coss(leftAngle) * CAPPY_MOVE_SPEED
                end
                
                if m.controller.buttonDown & R_JPAD ~= 0 then
                    -- Move right (perpendicular to Mario's facing angle)
                    local rightAngle = m.faceAngle.y - 0x4000
                    hat.oPosX = hat.oPosX + sins(rightAngle) * CAPPY_MOVE_SPEED
                    hat.oPosZ = hat.oPosZ + coss(rightAngle) * CAPPY_MOVE_SPEED
                end
            end
            -- END NEW CODE
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)

local function on_hat_command(msg)
    local lower = msg:lower()
    if msg == "0" then
        gPlayerSyncTable[0].hat = CAPPY_NONE
    elseif msg == "1" or lower == "top_hat" then
        gPlayerSyncTable[0].hat = CAPPY_1
    elseif msg == "2" or lower:find("mario") then
        gPlayerSyncTable[0].hat = CAPPY_MARIO_CAP
    else
        djui_chat_message_create("\\#ff0000\\Available: 0 (none), 1 (top_hat), 2 (marios_cap_geo), 3–10 (extra hats)")
        return true
    end
    djui_chat_message_create("Cappy was set to " .. gPlayerSyncTable[0].hat)
    return true
end

hook_chat_command("cappy", "[0–1] to select your hat, 0 being none", on_hat_command)

for i = 0, (MAX_PLAYERS - 1) do
    gPlayerSyncTable[i].hat = CAPPY_1
end

local backflipCount = 0
local jumpUsed = {}

local function ensure_state(i)
    if jumpUsed[i] == nil then
        jumpUsed[i] = false
    end
    return jumpUsed[i]
end

local function mario_update_abilities(m)
    if m.playerIndex ~= 0 then return end

    local hat = obj_get_first_with_behavior_id(id_bhvCappy2P)
    while hat ~= nil do
        if hat.oHatOwner == gNetworkPlayers[m.playerIndex].globalIndex then break end
        hat = obj_get_next_with_same_behavior_id(hat)
    end

    if hat == nil or hat.oHatPlaced ~= 0 then return end

    if (m.action & ACT_FLAG_AIR) == 0 then
        backflipCount = 0
        jumpUsed[m.playerIndex] = false
    end

    -- FIXED: Set animation BEFORE changing action, and force it to stay
    if m.controller.buttonPressed & L_TRIG ~= 0 and backflipCount < 2 then
        smlua_anim_util_set_animation(m.marioObj, "anim_mario_omm_cappy_vault")
        set_mario_action(m, ACT_TRIPLE_JUMP, 0)
        backflipCount = backflipCount + 1
    end
    
    -- Force the animation to play continuously during triple jump
    if m.action == ACT_TRIPLE_JUMP and backflipCount > 0 then
        smlua_anim_util_set_animation(m.marioObj, "anim_mario_omm_cappy_vault")
    end
    
    -- Force the animation to play continuously during triple jump
    if m.action == ACT_TRIPLE_JUMP and backflipCount > 0 then
        smlua_anim_util_set_animation(m.marioObj, "anim_mario_omm_cappy_vault")
    end

    local state = ensure_state(m.playerIndex)
    if m.controller.buttonPressed & L_JPAD ~= 0 then
        if not state then
            set_mario_action(m, ACT_JUMP, 0)
            m.vel.y = 50
            jumpUsed[m.playerIndex] = true
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update_abilities)