-- reverse bonk

local function reverse_bonk(m)
    if m.playerIndex ~= 0 then return end

    -- Only when already diving
    if m.action == ACT_DIVE then
        if m.controller.buttonPressed & R_JPAD ~= 0 then
            m.faceAngle.y = m.faceAngle.y + 0x8000
            m.forwardVel = 0
            set_mario_action(m, ACT_SOFT_BACKWARD_GROUND_KB, 0)
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, reverse_bonk)
